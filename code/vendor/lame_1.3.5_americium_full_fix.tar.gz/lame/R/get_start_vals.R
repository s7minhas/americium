#' Get fitted object from MCMC results
#'
#' @param start_vals List object that is null or contains
#' starting values
#' @param Y dependent variable in array format
#' @param family character vector (e.g. 'bin', 'nrm') specifying
#' family type
#' @param xP number of exogenous covariates
#' @param rvar logical indicating whether to include sender random
#' effects
#' @param cvar logical indicating whether to include receiver random
#' effects
#' @param R Number of dimensions for multiplicative effects
#' @param odmax vector of maximum ranks for cbin/frn families (optional)
#' @details In addition to the slots listed below, any of the dynamic
#'   hyperparameter scalars \code{rho_uv}, \code{sigma_uv}, \code{rho_ab},
#'   and \code{sigma_ab} present in \code{start_vals} (for example from
#'   \code{\link{als_start_vals}}) are passed through so a dynamic MCMC run
#'   can warm-start them.
#' @param bip logical; \code{TRUE} for a bipartite (rectangular) panel, in
#'   which case the Poisson start values keep the diagonal of a square matrix
#'   as a real cell
#' @return List of starting values for MCMC
#' @author Shahryar Minhas
#' @export get_start_vals

get_start_vals <- function(start_vals, Y, family, xP, rvar, cvar, R, odmax = NULL,
                           bip = FALSE){

	N <- dim(Y)[3]

	# partial start_vals are merged over defaults computed below, rather
	# than overriding every slot wholesale; that lets callers warm-start
	# just `beta` (say) without having to construct u/v/a/b/sab themselves.
	user_start <- start_vals
	if(!is.null(user_start) && !is.list(user_start)) {
		cli::cli_abort("{.arg start_vals} must be a list (or NULL).")
	}
	start_vals <- NULL

	if(is.null(start_vals)){

		####
		# initialize z values
		Z<-array(dim=dim(Y))
		for (t in 1:N) {
			if(family=="normal"){Z[,,t]<-Y[,,t] }
			if(family=="ordinal"){Z[,,t]<-matrix(zscores(Y[,,t]),nrow(Y[,,t]),ncol(Y[,,t]))}
			if(family=="binary" ){
				Z[,,t]<-matrix(zscores(Y[,,t]),nrow(Y[,,t]),nrow(Y[,,t]))
				zyMax <- if (sum(Y[,,t] == 0, na.rm = TRUE) > 0) {
					max(Z[,,t][Y[,,t] == 0], na.rm = TRUE)
				} else {
					min(Z[,,t][Y[,,t] == 1], na.rm = TRUE) - 1e-6
				}
				zyMin <- if (sum(Y[,,t] == 1, na.rm = TRUE) > 0) {
					min(Z[,,t][Y[,,t] == 1], na.rm = TRUE)
				} else {
					max(Z[,,t][Y[,,t] == 0], na.rm = TRUE) + 1e-6
				}
				z01<-.5*(zyMax+zyMin )
				Z[,,t]<-Z[,,t] - z01
			}
			if(family=="poisson"){
				# zero cells start at the period's mean rate rather than at
				# rate 1 (see .ame_pois_init_z in ame_unipartite.R)
				Z[,,t] <- .ame_pois_init_z(Y[,,t], unipartite = !bip)
			}

			if(is.element(family,c("cbin","frn"))) {
				if(is.null(odmax)) {
					cli::cli_abort("odmax must be provided for family=cbin/frn")
				}
				Z[,,t]<-Y[,,t]
				for(i in 1:nrow(Y[,,t])) {
					yi<-Y[i,,t]
					zi<-zscores(yi)
					rnkd<-which( !is.na(yi) & yi>0 )
					if(length(rnkd)>0 && min(zi[rnkd])<0) {
						zi[rnkd]<-zi[rnkd] - min(zi[rnkd]) + 1e-3
					}

					if(length(rnkd)<odmax[i])  {
						urnkd<-which( !is.na(yi) & yi==0 )
						if(length(urnkd) > 0 && max(zi[urnkd])>0) { zi[urnkd]<-zi[urnkd] - max(zi[urnkd]) -1e-3 }
					}

					Z[i,,t]<-zi
				}
			}
		}
		####

		####
		# fill missing entries with row/col mean imputation
		ZA<-Z
		for (t in 1:N) {
			mu<-mean(Z[,,t],na.rm=TRUE)
			a<-rowMeans(Z[,,t],na.rm=TRUE) ; b<-colMeans(Z[,,t],na.rm=TRUE)
			a[is.na(a)] <- 0 ; b[is.na(b)] <- 0
			ZA[,,t]<-mu + outer(a,b,"+")
		}
		Z[is.na(Z)]<-ZA[is.na(Z)]
		####

		####
		# initialize other parameters
		if(xP > 0) {
			beta <- rnorm(xP, mean=0, sd=0.1)
			z_mean <- mean(Z, na.rm=TRUE)
			if(!is.finite(z_mean)) {
				z_mean <- 0
			}
			beta[1] <- z_mean
		} else {
			beta <- numeric(0)
		}
		s2<-1
		rho<-0
		Sab<-cov(cbind(a,b))*tcrossprod(c(rvar,cvar))
		U<-V<-matrix(0, nrow(Y[,,1]), R)
		####

	}

	# merge any user-supplied slots over the defaults computed above
	if(!is.null(user_start)){
		if(!is.null(user_start$Z))    Z    <- user_start$Z
		if(!is.null(user_start$beta)) beta <- user_start$beta
		if(!is.null(user_start$a))    a    <- user_start$a
		if(!is.null(user_start$b))    b    <- user_start$b
		if(!is.null(user_start$U))    U    <- user_start$U
		if(!is.null(user_start$V))    V    <- user_start$V
		if(!is.null(user_start$rho))  rho  <- user_start$rho
		if(!is.null(user_start$s2))   s2   <- user_start$s2
		if(!is.null(user_start$Sab))  Sab  <- user_start$Sab
	}

	out <- list(
		Z=Z, beta=beta, a=a, b=b, U=U, V=V, rho=rho, s2=s2, Sab=Sab
	)

	# dynamic hyperparameter scalars (e.g. from als_start_vals) ride along
	# untouched; lame() reads them when the matching dynamic option is on
	for(nm in c("rho_uv", "sigma_uv", "rho_ab", "sigma_ab")){
		val <- user_start[[nm]]
		if(!is.null(val)){
			if(!is.numeric(val) || length(val) != 1L || !is.finite(val)){
				cli::cli_abort("{.arg start_vals${nm}} must be a single finite number.")
			}
			out[[nm]] <- val
		}
	}

	return(out)

}
