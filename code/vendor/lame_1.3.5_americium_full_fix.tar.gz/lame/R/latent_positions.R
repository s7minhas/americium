#' Extract latent positions as a tidy data frame
#'
#' @description
#' Extracts multiplicative latent factor positions (U and V) from a fitted
#' \code{ame}, \code{lame} or \code{ame_als} model and returns them as a
#' tidy data frame suitable for plotting and analysis. Optionally applies
#' Procrustes alignment for dynamic models and includes posterior standard
#' deviations when posterior samples are available.
#'
#' @param object A fitted \code{ame}, \code{lame} or \code{ame_als} model
#'   object with R > 0.
#' @param align Logical. For dynamic models (\code{dynamic_uv = TRUE}), apply
#'   Procrustes alignment across the time periods of this fit to remove
#'   rotational indeterminacy. Default is \code{FALSE} for \code{ame} objects
#'   (a single period, so there is nothing to align and the argument has no
#'   effect) and \code{TRUE} for \code{lame} objects.
#' @param ... Additional arguments (currently unused).
#'
#' @details
#' Alignment only ever happens across the periods of one fit: with
#' \code{align = TRUE} the fit is passed to \code{\link{procrustes_align}},
#' which rotates each period onto the one before it. Nothing here aligns two
#' different fits (two chains, or the same model with and without a
#' covariate) to a common orientation, so their latent positions are not
#' directly comparable. To compare fits that way, stack their \code{U}
#' matrices into an \code{[n, R, 2]} array (same actors in the same order,
#' same \code{R}) and call \code{procrustes_align(U = that_array)} on it.
#'
#' @return A data frame with columns:
#' \describe{
#'   \item{actor}{Character. Actor name (from rownames of U or V).}
#'   \item{dimension}{Integer. Latent dimension index (1 to R).}
#'   \item{time}{Character. Time period label. Dynamic fits use the time
#'     labels from the input; static (cross-sectional) fits return
#'     \code{"1"} for every row so downstream filtering by \code{time}
#'     behaves the same in both cases.}
#'   \item{value}{Numeric. The posterior mean latent position.}
#'   \item{posterior_sd}{Numeric. Posterior standard deviation of the latent
#'     position, or \code{NA} if posterior samples are not available.
#'     To enable, fit the model with
#'     \code{posterior_opts = posterior_options(save_UV = TRUE)}.}
#'   \item{type}{Character. \code{"U"} for sender/row positions,
#'     \code{"V"} for receiver/column positions. Symmetric models have
#'     only \code{"U"}.}
#' }
#'
#' Returns a zero-row data frame with correct column names if R = 0.
#'
#' @seealso \code{\link{procrustes_align}} for standalone Procrustes alignment,
#'   \code{\link{uv_plot}} for visualizing latent positions,
#'   \code{\link{posterior_options}} for enabling posterior sampling of U/V
#'
#' @examples
#' \donttest{
#' data(YX_nrm)
#' fit <- ame(YX_nrm$Y, Xdyad = YX_nrm$X, R = 2,
#'            burn = 5, nscan = 5, odens = 1, verbose = FALSE)
#' lp <- latent_positions(fit)
#' head(lp)
#' }
#'
#' @author Cassy Dorff, Shahryar Minhas, Tosin Salau
#' @export
latent_positions <- function(object, ...) {
	UseMethod("latent_positions")
}

#' @rdname latent_positions
#' @method latent_positions ame
#' @export
latent_positions.ame <- function(object, align = FALSE, ...) {
	.extract_latent_positions(object, align = align)
}

#' @rdname latent_positions
#' @method latent_positions lame
#' @export
latent_positions.lame <- function(object, align = TRUE, ...) {
	.extract_latent_positions(object, align = align)
}

#' @rdname latent_positions
#' @method latent_positions ame_als
#' @export
latent_positions.ame_als <- function(object, align = FALSE, ...) {
	# the fast estimator's u/v are static; posterior_sd is na (no samples)
	.extract_latent_positions(object, align = align)
}

# internal workhorse
.extract_latent_positions <- function(object, align = FALSE) {

	empty_df <- data.frame(
		actor = character(0),
		dimension = integer(0),
		time = character(0),
		value = numeric(0),
		posterior_sd = numeric(0),
		type = character(0),
		stringsAsFactors = FALSE
	)

	U <- object$U
	V <- object$V
	G <- object$G

	if (is.null(U)) return(empty_df)

	is_symmetric <- isTRUE(object$symmetric)
	is_bip <- identical(object$mode, "bipartite")

	# apply procrustes alignment if requested
	if (align && length(dim(U)) == 3L) {
		aligned <- procrustes_align(object = object)
		U <- aligned$U
		V <- aligned$V
		G <- aligned$G
	}

	# compute posterior sds from samples if available. static fits store
	# [n, R, S] cubes in U_samples/V_samples; dynamic fits store [n, R, T, S]
	# trajectories in U_draws/V_draws (posterior_opts save_UV / save_UV_draws).
	# note: dynamic-fit SDs are computed from the raw draws and therefore
	# include rotational variation across draws.
	U_sd <- .compute_posterior_sd(object$U_samples)
	V_sd <- .compute_posterior_sd(object$V_samples)
	if (is.null(U_sd) && !is.null(object$U_draws) &&
	    length(dim(object$U_draws)) == 4L) {
		U_sd <- apply(object$U_draws, c(1, 2, 3), sd, na.rm = TRUE)
	}
	if (is.null(V_sd) && !is.null(object$V_draws) &&
	    length(dim(object$V_draws)) == 4L) {
		V_sd <- apply(object$V_draws, c(1, 2, 3), sd, na.rm = TRUE)
	}

	# build data frames from arrays
	u_df <- .array_to_df(U, type = "U", sd_array = U_sd)

	if (is_symmetric || is.null(V)) {
		out <- u_df
	} else {
		v_df <- .array_to_df(V, type = "V", sd_array = V_sd)
		out <- rbind(u_df, v_df)
	}

	# tell users why posterior_sd is na (samples weren't saved)
	if (nrow(out) > 0L && all(is.na(out$posterior_sd))) {
		cli::cli_inform(c(
			"i" = "{.code posterior_sd} is {.val NA} because U/V samples were not saved.",
			"i" = "To get posterior SDs, refit with {.code posterior_opts = posterior_options(save_UV = TRUE)}."
		), .frequency = "once", .frequency_id = "latent_positions_no_sd")
	}

	out
}

# compute element-wise posterior sd from a 3d samples array [n, r, n_samples]
.compute_posterior_sd <- function(samples) {
	if (is.null(samples)) return(NULL)
	if (length(dim(samples)) != 3L) return(NULL)
	# apply sd across the samples dimension (3rd dim)
	apply(samples, c(1, 2), sd, na.rm = TRUE)
}

# convert a 2d matrix or 3d array to tidy data frame
# sd_array: optional matrix [n, r] of posterior sds (same shape as 2d x)
.array_to_df <- function(x, type, sd_array = NULL) {
	if (is.matrix(x) || length(dim(x)) == 2L) {
		# static: [n, r]
		actors <- rownames(x)
		if (is.null(actors)) actors <- paste0("node", seq_len(nrow(x)))
		R <- ncol(x)
		dfs <- lapply(seq_len(R), function(r) {
			sd_vals <- if (!is.null(sd_array) && ncol(sd_array) >= r) {
				sd_array[, r]
			} else {
				rep(NA_real_, nrow(x))
			}
			data.frame(
				actor = actors,
				dimension = r,
				# label static fits with time = "1" so downstream filtering
				# treats static and dynamic fits the same
				time = "1",
				value = x[, r],
				posterior_sd = sd_vals,
				type = type,
				stringsAsFactors = FALSE,
				row.names = NULL
			)
		})
		do.call(rbind, dfs)
	} else if (length(dim(x)) == 3L) {
		# dynamic: [n, r, t]
		actors <- dimnames(x)[[1]]
		if (is.null(actors)) actors <- paste0("node", seq_len(dim(x)[1]))
		time_labels <- dimnames(x)[[3]]
		if (is.null(time_labels)) time_labels <- as.character(seq_len(dim(x)[3]))
		R <- dim(x)[2]
		TT <- dim(x)[3]
		dfs <- vector("list", R * TT)
		idx <- 1L
		for (r in seq_len(R)) {
			for (t in seq_len(TT)) {
				# a 3-D sd_array carries per-period SDs (dynamic draws); a 2-D
				# one is per-actor per-dim, constant across time points
				sd_vals <- if (!is.null(sd_array) && length(dim(sd_array)) == 3L &&
				               dim(sd_array)[2] >= r && dim(sd_array)[3] >= t) {
					sd_array[, r, t]
				} else if (!is.null(sd_array) && length(dim(sd_array)) == 2L &&
				           ncol(sd_array) >= r) {
					sd_array[, r]
				} else {
					rep(NA_real_, dim(x)[1])
				}
				dfs[[idx]] <- data.frame(
					actor = actors,
					dimension = r,
					time = time_labels[t],
					value = x[, r, t],
					posterior_sd = sd_vals,
					type = type,
					stringsAsFactors = FALSE,
					row.names = NULL
				)
				idx <- idx + 1L
			}
		}
		do.call(rbind, dfs)
	} else {
		data.frame(
			actor = character(0), dimension = integer(0),
			time = character(0), value = numeric(0),
			posterior_sd = numeric(0),
			type = character(0), stringsAsFactors = FALSE
		)
	}
}
