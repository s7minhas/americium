####
#' Simulate networks from a fitted AME model
#' 
#' @description
#' Generates multiple network realizations from a fitted AME model. This
#' function performs conditional posterior predictive simulation: it draws from
#' stored MCMC samples when they are available and uses posterior means for
#' latent components that were not retained.
#' 
#' Unlike \code{print.ame}, which only displays fitted quantities,
#' \code{simulate.ame} draws new networks from the posterior predictive
#' distribution.
#' 
#' @param object fitted model object of class "ame"
#' @param nsim number of networks to simulate (default: 100)
#' @param seed random seed for reproducibility
#' @param newdata optional list containing new covariate data:
#'   \describe{
#'     \item{Xdyad}{dyadic covariates (n x n x p array or nA x nB x p for bipartite)}
#'     \item{Xrow}{row/sender covariates (n x p matrix or nA x p for bipartite)}
#'     \item{Xcol}{column/receiver covariates (n x p matrix or nB x p for bipartite)}
#'   }
#'   If NULL, uses covariates from original model fit
#' @param burn_in number of initial MCMC samples to discard (default: 0, assumes
#'   burn-in already removed)
#' @param thin thinning interval for MCMC samples (default: 1, use every sample)
#' @param return_latent logical: return latent Z matrices in addition to Y? (default: FALSE)
#' @param ... additional arguments (not currently used)
#' 
#' @return A list with components:
#'   \describe{
#'     \item{Y}{list of nsim simulated networks in the same format as the original data}
#'     \item{Z}{if return_latent=TRUE, list of nsim latent Z matrices}
#'     \item{family}{the family of the model (binary, normal, etc.)}
#'     \item{mode}{network mode (unipartite or bipartite)}
#'   }
#'
#' @details
#' \strong{Model:}
#' 
#' The AME model represents networks through a latent variable framework:
#' \deqn{Y_{ij} \sim F(Z_{ij})}
#' where F is the observation model (e.g., probit for binary) and Z is the latent network:
#' \deqn{Z_{ij} = \beta^T x_{ij} + a_i + b_j + u_i^T v_j + \epsilon_{ij}}
#' 
#' Components:
#' \itemize{
#'   \item \eqn{\beta}: regression coefficients for dyadic/nodal covariates
#'   \item \eqn{a_i, b_j}: additive sender and receiver random effects
#'   \item \eqn{u_i, v_j}: multiplicative latent factors (dimension R)
#'   \item \eqn{\epsilon_{ij}}: dyadic random effects with correlation \eqn{\rho}
#' }
#' 
#' \strong{Simulation:}
#' 
#' For each simulated network k = 1, ..., nsim:
#' 
#' 1. \strong{Parameter draw:} Draw parameter set \eqn{\theta^{(k)}} from MCMC chains:
#'    \itemize{
#'      \item Sample iteration s uniformly from stored MCMC samples
#'      \item Extract \eqn{\beta^{(s)}}, variance components \eqn{(v_a^{(s)}, v_b^{(s)}, v_e^{(s)}, \rho^{(s)})}
#'    }
#' 
#' 2. \strong{Random effects:} Sample new random effects from posterior distributions:
#'    \itemize{
#'      \item \eqn{a_i^{(k)} \sim N(0, v_a^{(s)})} for i = 1, ..., n (row effects)
#'      \item \eqn{b_j^{(k)} \sim N(0, v_b^{(s)})} for j = 1, ..., m (column effects)
#'      \item Fresh draws from the posterior variance carry random-effect
#'            uncertainty into the simulated networks
#'    }
#' 
#' 3. \strong{Latent network:} Build expected latent positions:
#'    \deqn{E[Z_{ij}^{(k)}] = \beta^{(s)T} x_{ij} + a_i^{(k)} + b_j^{(k)} + \hat{u}_i^T \hat{v}_j}
#'    where \eqn{\hat{u}_i, \hat{v}_j} are posterior mean latent factors
#' 
#' 4. \strong{Dyadic correlation:} Add correlated noise structure:
#'    \deqn{Z_{ij}^{(k)} = E[Z_{ij}^{(k)}] + \epsilon_{ij}^{(k)}}
#'    where \eqn{\epsilon} has covariance structure:
#'    \deqn{Cov(\epsilon_{ij}, \epsilon_{ji}) = \rho^{(s)} v_e^{(s)}}
#'    \deqn{Var(\epsilon_{ij}) = v_e^{(s)}}
#' 
#' 5. \strong{Observation model:} Generate the observed network:
#'    \itemize{
#'      \item Binary: \eqn{Y_{ij}^{(k)} = I(Z_{ij}^{(k)} > 0)}
#'      \item Normal: \eqn{Y_{ij}^{(k)} = Z_{ij}^{(k)}}
#'      \item Poisson: \eqn{Y_{ij}^{(k)} \sim Poisson(\exp(Z_{ij}^{(k)}))}
#'      \item Other families use appropriate link functions
#'    }
#' 
#' \strong{Sources of uncertainty:}
#' 
#' The simulation captures three types of uncertainty:
#' 
#' 1. \strong{Parameter uncertainty:} Different MCMC samples yield different \eqn{\beta, v_a, v_b, v_e, \rho}
#' 2. \strong{Random effect uncertainty:} Fresh draws from \eqn{N(0, v_a), N(0, v_b)} for each simulation
#' 3. \strong{Dyadic uncertainty:} Correlated random noise \eqn{\epsilon_{ij}}
#' 
#' The resulting simulations propagate uncertainty from the stored parameter
#' draws and from fresh dyadic/random-effect draws. Latent components that were
#' not stored as MCMC draws are held at their posterior means.
#' 
#' \strong{Latent-factor draws:}
#' 
#' Multiplicative effects (U, V) use posterior means unless the fit retained
#' compatible latent-factor draws. Storing full latent-factor chains can require
#' substantial additional memory.
#' 
#' \strong{Symmetric Networks:}
#' 
#' For symmetric networks, the model enforces \eqn{a_i = b_i} and \eqn{u_i = v_i},
#' and the latent matrix Z is symmetrized before generating observations.
#'
#' @examples
#' \donttest{
#' # Fit a model
#' data(YX_bin)
#' fit <- ame(YX_bin$Y, Xdyad = YX_bin$X, burn = 10, nscan = 100, odens = 1,
#'            family = "binary", verbose = FALSE)
#'
#' # Simulate 10 networks from posterior
#' sims <- simulate(fit, nsim = 10)
#' }
#' 
#' @author Cassy Dorff, Shahryar Minhas, Tosin Salau
#' @importFrom stats simulate
#' @method simulate ame
#' @export
simulate.ame <- function(
	object, nsim = 100, seed = NULL, newdata = NULL,
	burn_in = 0, thin = 1, return_latent = FALSE, ...
	){
	
	if (!is.null(seed)) set.seed(seed)

	fit <- object
	family <- if (!is.null(fit$family)) fit$family else "normal"
	symmetric <- if (!is.null(fit$symmetric)) {
		if (is.na(fit$symmetric)) FALSE else fit$symmetric
	} else FALSE
	mode <- if (!is.null(fit$mode)) fit$mode else "unipartite"
	bip <- (mode == "bipartite")
	
	if (bip) {
		nA <- fit$nA
		nB <- fit$nB
		n_row <- nA
		n_col <- nB
	} else {
		n <- length(fit$APM)
		n_row <- n_col <- n
	}
	
	####
	BETA <- fit$BETA
	VC <- fit$VC

	# burn-in and thinning
	if (burn_in > 0 && burn_in < nrow(BETA)) {
		BETA <- BETA[-(1:burn_in), , drop = FALSE]
		VC <- VC[-(1:burn_in), , drop = FALSE]
	}
	if (thin > 1) {
		keep <- seq(1, nrow(BETA), by = thin)
		BETA <- BETA[keep, , drop = FALSE]
		VC <- VC[keep, , drop = FALSE]
	}
	
	n_mcmc <- nrow(BETA)

	####
	# covariates
	if (!is.null(newdata)) {
		# build the design array the fit used so x aligns with beta
		has_int <- "intercept" %in% colnames(BETA)
		if (bip) {
			Xdyad <- newdata$Xdyad
			if (!is.null(Xdyad) && length(dim(Xdyad)) == 2) {
				Xdyad <- array(Xdyad, dim = c(dim(Xdyad), 1))
			}
			X <- Xdyad
		} else {
			X <- design_array(newdata$Xrow, newdata$Xcol, newdata$Xdyad,
			                  intercept = has_int, n = n_row, warn = FALSE)
			if (dim(X)[3] != ncol(BETA)) {
				cli::cli_abort(paste0("newdata covariates produce ", dim(X)[3],
				     " design columns but the fit has ", ncol(BETA),
				     " coefficients. Supply the covariates the model was fit with."))
			}
		}
	} else {
		if (!is.null(fit$X)) {
			X <- fit$X
		} else {
			cli::cli_warn(paste0("Original covariates not stored in model. Using zero covariates. ",
							"Consider providing covariates via newdata argument."))
			X <- array(0, dim = c(n_row, n_col, 1))
		}
	}
	
	####
	Y_sims <- vector("list", nsim)
	if (return_latent) {
		Z_sims <- vector("list", nsim)
	}

	# simulate networks
	for (i in 1:nsim) {
		s <- sample(1:n_mcmc, 1)
		beta <- BETA[s, ]

		# extract variance components
		vc_names <- colnames(VC)
		if (!is.null(vc_names)) {
			s2 <- if ("ve" %in% vc_names) VC[s, "ve"] else VC[s, ncol(VC)]
			rho <- if ("rho" %in% vc_names) VC[s, "rho"] else 0
			a_var <- if ("va" %in% vc_names) VC[s, "va"] else VC[s, 1]
			b_var <- if ("vb" %in% vc_names) VC[s, "vb"] else a_var
			
			a_var <- max(a_var, 0.01)
			b_var <- max(b_var, 0.01)
			s2 <- max(s2, 0.01)
		} else {
			if (symmetric) {
				s2 <- VC[s, ncol(VC)]
				rho <- 0
				a_var <- VC[s, 1]
				b_var <- a_var
			} else {
				if (bip) {
					s2 <- VC[s, 3]
					rho <- 0
					a_var <- VC[s, 1]
					b_var <- VC[s, 2]
				} else {
					s2 <- VC[s, ncol(VC)]
					rho <- VC[s, ncol(VC) - 1]
					a_var <- VC[s, 1]
					b_var <- VC[s, 3]
				}
			}
			a_var <- max(a_var, 0.01)
			b_var <- max(b_var, 0.01)
			s2 <- max(s2, 0.01)
		}
		
		# additive effects use saved posterior draws when available; otherwise use
		# the fitted posterior means
		if (!is.null(fit$a_samples)) {
			a <- fit$a_samples[, sample.int(ncol(fit$a_samples), 1)]
		} else if (!is.null(fit$APM) && length(fit$APM) == n_row) {
			a <- as.numeric(fit$APM)
		} else if (bip) {
			a <- rnorm(nA, mean = 0, sd = sqrt(a_var))
		} else {
			a <- rnorm(n, mean = 0, sd = sqrt(a_var))
		}
		if (isTRUE(symmetric) && !bip) {
			b <- a
		} else if (!is.null(fit$b_samples)) {
			b <- fit$b_samples[, sample.int(ncol(fit$b_samples), 1)]
		} else if (!is.null(fit$BPM) && length(fit$BPM) == n_col) {
			b <- as.numeric(fit$BPM)
		} else if (bip) {
			b <- rnorm(nB, mean = 0, sd = sqrt(b_var))
		} else {
			b <- rnorm(n, mean = 0, sd = sqrt(b_var))
		}
		
		# linear predictor
		if (length(beta) > 0 && any(beta != 0)) {
			if (length(dim(X)) == 3 && dim(X)[3] > 0) {
				# covariates * beta
				EZ <- array(0, dim = c(n_row, n_col))
				for (k in 1:min(dim(X)[3], length(beta))) {
					EZ <- EZ + beta[k] * X[, , k]
				}
			} else {
				EZ <- matrix(beta[1], n_row, n_col)  # intercept only
			}
		} else {
			EZ <- matrix(0, n_row, n_col)
		}
		
		EZ <- EZ + outer(a, b, "+")

		# multiplicative effects: per-draw posterior samples if saved,
		# else the posterior-mean u/v
		U_s <- fit$U; V_s <- fit$V
		if (!is.null(fit$U_samples)) {
			uidx <- sample.int(dim(fit$U_samples)[3], 1)
			U_s  <- fit$U_samples[, , uidx]
			V_s  <- if (!is.null(fit$V_samples)) fit$V_samples[, , uidx] else U_s
		}
		if (!is.null(U_s) && !is.null(V_s)) {
			if (bip && !is.null(fit$G)) {
				EZ <- EZ + U_s %*% fit$G %*% t(V_s)
			} else if (!bip) {
				EZ <- EZ + U_s %*% t(V_s)
			}
		}
		
		if (symmetric && !bip) {
			EZ <- (EZ + t(EZ)) / 2
		}
		
		# simulate y
		if (family == "binary") {
			Y_sim <- simY_bin(EZ, rho)
		} else if (family == "normal") {
			Y_sim <- simY_nrm(EZ, rho, s2)
		} else if (family == "ordinal") {
			# simy_ord wants y (for the unique-category lookup), not the
			# nonexistent fit$odm slot. use the posterior-predictive mean
			# or the original y as a category template.
			y_for_sim <- fit$Y %||% fit$YPM
			if (is.null(y_for_sim)) cli::cli_abort("simulate.ame: ordinal needs `fit$Y` to be present.")
			Y_sim <- simY_ord(EZ, rho, y_for_sim)
		} else if (family == "poisson") {
			# include the latent overdispersion layer of the fitted model
			# (y ~ Pois(exp(z)), z ~ N(EZ, s2*Sigma_rho))
			Y_sim <- simY_pois(simZ(EZ, rho, s2))
		} else if (family == "cbin") {
			# censored binary: an frn draw thresholded at zero, the same
			# posterior-predictive convention the fitter's gof draws use
			odmax <- if (!is.null(fit$odmax)) fit$odmax else rep(Inf, n_row)
			Y_sim <- 1 * (simY_frn(EZ, rho, odmax) > 0)
		} else if (family == "frn") {
			odmax <- if (!is.null(fit$odmax)) fit$odmax else rep(Inf, n_row)
			Y_sim <- simY_frn(EZ, rho, odmax)
		} else {
			cli::cli_abort(paste0("Family ", family, " not yet implemented for simulation"))
		}
		
		if (!bip) {
			diag(Y_sim) <- NA
		}
		# symmetric fit -> each posterior-predictive draw must also be
		# symmetric. ez is already symmetrized above but simy_* draws independent
		# noise per cell, breaking symmetry; mirror the upper triangle here.
		if (isTRUE(symmetric) && !bip && nrow(Y_sim) == ncol(Y_sim)) {
			ut <- upper.tri(Y_sim)
			Y_sim[lower.tri(Y_sim)] <- t(Y_sim)[lower.tri(Y_sim)]
		}

		Y_sims[[i]] <- Y_sim
		if (return_latent) {
			Z_sims[[i]] <- simZ(EZ, rho, s2)
		}
	}

	####
	result <- list(
		Y = Y_sims,
		family = family,
		mode = mode
	)
	
	if (return_latent) {
		result$Z <- Z_sims
	}
	
	class(result) <- "ame.sim"
	return(result)
}
####
