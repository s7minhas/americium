# exact unordered-dyad gaussian updates for static beta and shared a

.lame_exact_sym_design = function(x_list, g, active_a = TRUE){
	n = dim(x_list[[1]])[1]
	p = dim(x_list[[1]])[3]
	periods = length(x_list)
	mask = upper.tri(matrix(0, n, n))
	edges = which(mask, arr.ind = TRUE)
	x_edges = vector('list', periods)
	q_beta = prior_beta = matrix(0, p, p)
	q_cross = matrix(0, p, n)
	if(length(g) != 1 || !is.finite(g) || g <= 0){ stop('The exact symmetric block requires finite scalar g > 0.') }
	for(t in seq_len(periods)){
		x = x_list[[t]]
		if(!identical(as.integer(dim(x)), as.integer(c(n, n, p))) || any(!is.finite(x))){
			stop('Invalid exact symmetric design.')
		}
		full = matrix(x, n * n, p)
		flat = full[as.vector(mask), , drop = FALSE]
		x_edges[[t]] = flat
		if(p > 0){
			for(k in seq_len(p)){
				if(max(abs(x[, , k] - t(x[, , k]))) > 1e-10){
					stop('The exact symmetric block requires symmetric covariate matrices.')
				}
				m = matrix(0, n, n)
				m[edges] = flat[, k]
				m[cbind(edges[, 2], edges[, 1])] = flat[, k]
				q_cross[k, ] = q_cross[k, ] + rowSums(m)
			}
			q_beta = q_beta + crossprod(flat)
			prior_beta = prior_beta + crossprod(full) / (g * periods)
		}
	}
	q_actor = periods * (matrix(1, n, n) + diag(n - 2, n))
	list(n = n, p = p, periods = periods, mask = mask, edges = edges,
		x_edges = x_edges, q_beta = q_beta, prior_beta = prior_beta,
		q_cross = q_cross, q_actor = q_actor, active_a = active_a)
}

.lame_exact_sym_z = function(y, mean, s2){
	n = dim(y)[1]
	periods = dim(y)[3]
	mask = upper.tri(matrix(0, n, n))
	z = y
	for(t in seq_len(periods)){
		observed = y[, , t]
		left = observed[mask]
		right = t(observed)[mask]
		both = is.finite(left) & is.finite(right)
		if(any(abs(left[both] - right[both]) > 1e-10)){
			stop('Observed reciprocal values differ in the exact symmetric model.')
		}
		left[!is.finite(left)] = right[!is.finite(left)]
		missing = !is.finite(left)
		left[missing] = rnorm(sum(missing), mean[, , t][mask][missing], sqrt(s2))
		m = matrix(0, n, n)
		m[mask] = left
		m = m + t(m)
		# self-dyads are excluded from every likelihood conditional
		diag(m) = diag(mean[, , t])
		z[, , t] = m
	}
	z
}

.lame_exact_sym_ab = function(z, u, v, s2, va, design, return_moments = FALSE){
	n = design$n
	p = design$p
	active_a = design$active_a
	h_beta = numeric(p)
	h_actor = numeric(n)
	for(t in seq_len(design$periods)){
		u_t = if(length(dim(u)) == 3) matrix(u[, , t], n, dim(u)[2]) else u
		v_t = if(length(dim(v)) == 3) matrix(v[, , t], n, dim(v)[2]) else v
		residual = z[, , t] - u_t %*% t(v_t)
		diag(residual) = 0
		if(p > 0){ h_beta = h_beta + c(crossprod(design$x_edges[[t]], residual[design$mask])) }
		h_actor = h_actor + rowSums(residual)
	}
	if(active_a){
		if(!is.finite(va) || va <= 0){ stop('The shared actor variance must be positive.') }
		precision = rbind(cbind(design$q_beta / s2 + design$prior_beta, design$q_cross / s2),
			cbind(t(design$q_cross) / s2, design$q_actor / s2 + diag(1 / va, n)))
		linear = c(h_beta, h_actor) / s2
	} else {
		precision = design$q_beta / s2 + design$prior_beta
		linear = h_beta / s2
	}
	if(length(linear) == 0){ return(list(beta = numeric(0), a = numeric(n), b = numeric(n))) }
	root = chol(precision)
	post_mean = backsolve(root, forwardsolve(t(root), linear))
	if(return_moments){ return(list(mean = post_mean, covariance = chol2inv(root), precision = precision)) }
	draw = post_mean + backsolve(root, rnorm(length(linear)))
	beta = if(p > 0) draw[seq_len(p)] else numeric(0)
	a = if(active_a) draw[p + seq_len(n)] else numeric(n)
	list(beta = beta, a = a, b = a)
}

.lame_exact_sym_s2 = function(residual, shape = 0.5, scale = 0.5){
	n = dim(residual)[1]
	mask = upper.tri(matrix(0, n, n))
	values = unlist(lapply(seq_len(dim(residual)[3]), function(t){ residual[, , t][mask] }))
	if(any(!is.finite(values))){ stop('The exact variance update requires finite augmented dyads.') }
	1 / rgamma(1, shape = shape + length(values) / 2, rate = scale + sum(values^2) / 2)
}
