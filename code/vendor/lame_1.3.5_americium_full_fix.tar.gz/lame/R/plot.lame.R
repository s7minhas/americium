#' Plot diagnostics for a LAME model fit
#' 
#' Creates diagnostic plots for a LAME (Longitudinal 
#' Additive and Multiplicative Effects) model, including MCMC diagnostics, 
#' parameter evolution over time, and longitudinal goodness-of-fit checks. 
#' This is the default plot method for LAME objects.
#' 
#' @details
#' The function produces a multi-panel plot containing:
#' \describe{
#'   \item{MCMC trace plots}{Shows mixing and convergence of key parameters}
#'   \item{Posterior distributions}{Density plots of regression coefficients 
#'         and variance components}
#'   \item{Longitudinal GOF}{Time series of observed network statistics with
#'         posterior predictive intervals}
#'   \item{Effects over time}{Evolution of additive effects across time periods
#'         (if applicable)}
#'   \item{Network snapshots}{Visualization of network at selected time points}
#' }
#' 
#' The plot adapts to the longitudinal structure:
#' - Shows temporal trends in network statistics
#' - Highlights composition changes if actors enter/exit
#' - Displays credible intervals for time-varying statistics
#' 
#' @param x an object of class "lame" from fitting a LAME model
#' @param which numeric or character vector specifying which plots to produce:
#'        1 or "trace" = MCMC trace plots,
#'        2 or "density" = posterior density plots,
#'        3 or "gof" = longitudinal goodness-of-fit plots,
#'        4 or "effects" = additive and multiplicative effects,
#'        5 or "network" = network snapshots at selected times.
#'        Default is c(1,2,3,4) to show main diagnostic plots.
#' @param time.points numeric vector of time points for network snapshots
#'        (only used if "network" in which). Default is c(1, middle, last).
#' @param ask logical; if TRUE, user is prompted before each plot page
#' @param pages character string specifying how to arrange plots:
#'        "single" = one combined page (default),
#'        "multiple" = separate pages for each plot type
#' @param ... additional arguments (currently not used)
#' @return NULL (invisibly). Plots are displayed as side effects.
#' @author Cassy Dorff, Shahryar Minhas, Tosin Salau
#' @seealso \code{\link{lame}}, \code{\link{trace_plot}}, \code{\link{gof_plot}}, 
#'          \code{\link{ab_plot}}, \code{\link{uv_plot}}
#' @examples
#' \donttest{
#' # Create simple longitudinal network data
#' set.seed(6886)
#' n <- 10
#' nms <- paste0("n", 1:n)
#' Y_list <- list(
#'   matrix(rnorm(n * n), n, n, dimnames = list(nms, nms)),
#'   matrix(rnorm(n * n), n, n, dimnames = list(nms, nms))
#' )
#' diag(Y_list[[1]]) <- diag(Y_list[[2]]) <- NA
#' fit <- lame(Y_list, family = "normal",
#'             nscan = 50, burn = 10, odens = 1, verbose = FALSE, plot = FALSE)
#'
#' # default combined plot
#' plot(fit)
#' }
#' @method plot lame
#' @export
#' @import ggplot2
#' @import patchwork
plot.lame <- function(x, 
											which = c(1, 2, 3, 4),
											time.points = NULL,
											ask = FALSE,
											pages = c("single", "multiple"),
											...) {
	
	fit <- x
	pages <- match.arg(pages)

	# dynamic_beta fits store BETA as a 3-D array [iter x coef x period];
	# the trace/density panels below index it as a 2-D [iter x coef] matrix,
	# which errors on a 3-D array. collapse to the period-averaged
	# coefficient path for these summary panels (per-period trajectories are
	# available via trace_plot()/autoplot()).
	BETA_2d <- fit$BETA
	if (!is.null(BETA_2d) && length(dim(BETA_2d)) == 3L) {
		BETA_2d <- apply(BETA_2d, c(1, 2), mean)
	}

	plot_types <- c()
	if (is.numeric(which)) {
		if (1 %in% which) plot_types <- c(plot_types, "trace")
		if (2 %in% which) plot_types <- c(plot_types, "density")
		if (3 %in% which) plot_types <- c(plot_types, "gof")
		if (4 %in% which) plot_types <- c(plot_types, "effects")
		if (5 %in% which) plot_types <- c(plot_types, "network")
	} else {
		plot_types <- which
	}
	
	has_patchwork <- requireNamespace("patchwork", quietly = TRUE)
	if (!has_patchwork && pages == "single") {
		cli::cli_warn("Package {.pkg patchwork} not installed. Switching to multiple pages.")
		pages <- "multiple"
	}
	
	# label mappings
	vc_labels <- c(
		"va" = "Sender Variance",
		"vb" = "Receiver Variance",
		"cab" = "Sender-Receiver Covariance",
		"rho" = "Dyadic Correlation",
		"ve" = "Error Variance"
	)
	gof_stat_labels <- c(
		"sd.rowmean" = "Sender Degree Heterogeneity",
		"sd.colmean" = "Receiver Degree Heterogeneity",
		"dyad.dep" = "Dyadic Dependence",
		"cycle.dep" = "Triadic Dependence",
		"four.cycles" = "Four Cycles",
		"trans.dep" = "Transitivity"
	)
	relabel <- function(x, mapping) {
		ifelse(x %in% names(mapping), mapping[x], x)
	}

	# standard theme used by all sub-plots in plot.lame()
	lame_theme <- theme_bw() +
		theme(
			panel.border     = element_blank(),
			axis.ticks       = element_blank(),
			legend.position  = "top",
			strip.background = element_rect(fill = "black", color = "black"),
			strip.text       = element_text(color = "white", hjust = 0, size = 8),
			panel.spacing    = unit(0.5, "lines")
		)

	plot_list <- list()

	####
	# mcmc trace plots
	if ("trace" %in% plot_types) {
		trace_data <- data.frame()

		if (!is.null(fit$VC)) {
			vc_names <- colnames(fit$VC)
			for (i in 1:ncol(fit$VC)) {
				trace_data <- rbind(trace_data, data.frame(
					iteration = 1:nrow(fit$VC),
					value = fit$VC[, i],
					parameter = vc_names[i],
					type = "Variance",
					stringsAsFactors = FALSE
				))
			}
		}

		if (!is.null(BETA_2d) && ncol(BETA_2d) > 0) {
			n_beta <- min(6, ncol(BETA_2d))
			beta_names <- colnames(BETA_2d)[1:n_beta]
			for (i in 1:n_beta) {
				trace_data <- rbind(trace_data, data.frame(
					iteration = 1:nrow(BETA_2d),
					value = BETA_2d[, i],
					parameter = beta_names[i],
					type = "Regression",
					stringsAsFactors = FALSE
				))
			}
		}

		if (nrow(trace_data) > 0) {
			trace_data$parameter <- relabel(trace_data$parameter, vc_labels)

			p_trace <- ggplot(trace_data, aes(x = iteration, y = value)) +
				geom_line(alpha = 0.7) +
				facet_wrap(~ parameter, scales = "free_y", ncol = 3) +
				labs(title = "MCMC Trace Plots", x = "Iteration", y = "Value") +
				lame_theme

			plot_list[["trace"]] <- p_trace
		}
	}
	####

	####
	# posterior density plots
	if ("density" %in% plot_types) {
		density_data <- data.frame()
		
		if (!is.null(fit$VC)) {
			vc_names <- colnames(fit$VC)
			for (i in 1:ncol(fit$VC)) {
				density_data <- rbind(density_data, data.frame(
					value = fit$VC[, i],
					parameter = vc_names[i],
					type = "Variance",
					stringsAsFactors = FALSE
				))
			}
		}
		
		if (!is.null(BETA_2d) && ncol(BETA_2d) > 0) {
			n_beta <- min(6, ncol(BETA_2d))
			beta_names <- colnames(BETA_2d)[1:n_beta]
			for (i in 1:n_beta) {
				density_data <- rbind(density_data, data.frame(
					value = BETA_2d[, i],
					parameter = beta_names[i],
					type = "Regression",
					stringsAsFactors = FALSE
				))
			}
		}
		
		if (nrow(density_data) > 0) {
			density_data$parameter <- relabel(density_data$parameter, vc_labels)

			p_density <- ggplot(density_data, aes(x = value)) +
				geom_density() +
				geom_vline(xintercept = 0, linetype = "dashed", alpha = 0.5) +
				facet_wrap(~ parameter, scales = "free", ncol = 3) +
				labs(title = "Posterior Distributions", x = "Value", y = "Density") +
				lame_theme

			plot_list[["density"]] <- p_density
		}
	}
	####

	####
	# goodness-of-fit plots
	if ("gof" %in% plot_types) {
		if (!is.null(fit$GOF_T)) {
			gof_data_list <- fit$GOF_T
			n_time <- length(gof_data_list)
			
			gof_long_data <- data.frame()
			
			for (t in 1:n_time) {
				gof_t <- gof_data_list[[t]]
				if (!is.null(gof_t) && nrow(gof_t) > 1) {
					obs_t <- gof_t[1, ]
					pred_t <- gof_t[-1, , drop = FALSE]
					
					for (j in 1:ncol(gof_t)) {
						stat_name <- colnames(gof_t)[j]
						pred_vals <- pred_t[, j]
						pred_vals <- pred_vals[!is.na(pred_vals)]
						if (length(pred_vals) > 0) {
							gof_long_data <- rbind(gof_long_data, data.frame(
								time = t,
								statistic = stat_name,
								observed = obs_t[j],
								median = median(pred_vals),
								lower = quantile(pred_vals, 0.025),
								upper = quantile(pred_vals, 0.975),
								stringsAsFactors = FALSE
							))
						}
					}
				}
			}
			
			if (nrow(gof_long_data) > 0) {
				gof_long_data$statistic <- relabel(gof_long_data$statistic, gof_stat_labels)

				p_gof <- ggplot(gof_long_data, aes(x = time)) +
					geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.3) +
					geom_line(aes(y = median), linewidth = 1, linetype = "dashed") +
					geom_line(aes(y = observed), color = "red", linewidth = 1) +
					geom_point(aes(y = observed), color = "red", size = 2) +
					facet_wrap(~ statistic, scales = "free_y", ncol = 2) +
					labs(title = "Longitudinal GOF: Observed (Red) vs 95% Credible Intervals",
							 x = "Time Period", y = "Value") +
					lame_theme

				plot_list[["gof"]] <- p_gof
			}
		} else if (!is.null(fit$GOF) && is.array(fit$GOF) && length(dim(fit$GOF)) == 3) {
			gof_long_data <- data.frame()
			n_stats <- dim(fit$GOF)[1]
			n_time <- dim(fit$GOF)[2]
			n_iter <- dim(fit$GOF)[3]
			
			stat_names <- dimnames(fit$GOF)[[1]]
			time_names <- dimnames(fit$GOF)[[2]]
			if (is.null(time_names)) time_names <- 1:n_time
			
			for (t in 1:n_time) {
				obs_t <- fit$GOF[, t, 1]
				
				if (n_iter > 1) {
					for (s in 1:n_stats) {
						stat_name <- stat_names[s]
						pred_vals <- fit$GOF[s, t, 2:n_iter]
						
						pred_vals <- pred_vals[!is.na(pred_vals)]
						if (length(pred_vals) > 0) {
							gof_long_data <- rbind(gof_long_data, data.frame(
								time = time_names[t],
								statistic = stat_name,
								observed = obs_t[s],
								median = median(pred_vals),
								lower = quantile(pred_vals, 0.025),
								upper = quantile(pred_vals, 0.975),
								stringsAsFactors = FALSE
							))
						}
					}
				}
			}
			
			if (nrow(gof_long_data) > 0) {
				gof_long_data$statistic <- relabel(gof_long_data$statistic, gof_stat_labels)

				p_gof <- ggplot(gof_long_data, aes(x = as.numeric(factor(time)))) +
					geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.3) +
					geom_line(aes(y = median), linewidth = 1, linetype = "dashed") +
					geom_line(aes(y = observed), color = "red", linewidth = 1) +
					geom_point(aes(y = observed), color = "red", size = 2) +
					facet_wrap(~ statistic, scales = "free_y", ncol = 2) +
					labs(title = "Longitudinal GOF: Observed (Red) vs 95% Credible Intervals",
							 x = "Time Period", y = "Value") +
					scale_x_continuous(breaks = 1:n_time, labels = time_names) +
					lame_theme

				plot_list[["gof"]] <- p_gof
			}
		} else if (!is.null(fit$GOF) && is.list(fit$GOF) && !is.data.frame(fit$GOF)) {
			# gof stored as named list
			gof_long_data <- data.frame()
			stat_names <- names(fit$GOF)
			
			# check for time-indexed gof data
			if (ncol(fit$GOF[[1]]) > 1) {
				n_time <- ncol(fit$GOF[[1]])
				
				for (t in 1:n_time) {
					for (stat_name in stat_names) {
						vals <- fit$GOF[[stat_name]][, t]
						if (length(vals) > 1) {
							obs_val <- vals[1]
							pred_vals <- vals[-1]
							
							pred_vals <- pred_vals[!is.na(pred_vals)]
							if (length(pred_vals) > 0) {
								gof_long_data <- rbind(gof_long_data, data.frame(
									time = t,
									statistic = stat_name,
									observed = obs_val,
									median = median(pred_vals),
									lower = quantile(pred_vals, 0.025),
									upper = quantile(pred_vals, 0.975),
									stringsAsFactors = FALSE
								))
							}
						}
					}
				}
				
				if (nrow(gof_long_data) > 0) {
					gof_long_data$statistic <- relabel(gof_long_data$statistic, gof_stat_labels)

					p_gof <- ggplot(gof_long_data, aes(x = time)) +
						geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.3) +
						geom_line(aes(y = median), linewidth = 1, linetype = "dashed") +
						geom_line(aes(y = observed), color = "red", linewidth = 1) +
						geom_point(aes(y = observed), color = "red", size = 2) +
						facet_wrap(~ statistic, scales = "free_y", ncol = 2) +
						labs(title = "Longitudinal GOF: Observed (Red) vs 95% Credible Intervals",
								 x = "Time Period", y = "Value") +
						lame_theme

					plot_list[["gof"]] <- p_gof
				}
			} else {
				# single time point, use static gof display
				gof_plot_data <- data.frame()
				for (stat_name in stat_names) {
					vals <- fit$GOF[[stat_name]][, 1]
					if (length(vals) > 1) {
						obs_val <- vals[1]
						pred_vals <- vals[-1]
						
						gof_plot_data <- rbind(gof_plot_data, data.frame(
							value = pred_vals,
							statistic = stat_name,
							observed = obs_val,
							stringsAsFactors = FALSE
						))
					}
				}
				
				if (nrow(gof_plot_data) > 0) {
					gof_plot_data$statistic <- relabel(gof_plot_data$statistic, gof_stat_labels)

					p_gof <- ggplot(gof_plot_data, aes(x = value)) +
						geom_histogram(aes(y = after_stat(density)), bins = 30) +
						geom_vline(aes(xintercept = observed),
											color = "red", linewidth = 1) +
						facet_wrap(~ statistic, scales = "free", ncol = 2) +
						labs(title = "GOF: Observed (Red) vs Posterior Predictive",
								 x = "Value", y = "Density") +
						lame_theme

					plot_list[["gof"]] <- p_gof
				}
			}
		} else if (!is.null(fit$GOF) && is.matrix(fit$GOF) && nrow(fit$GOF) > 1) {
			# fallback: static gof from 2d matrix
			gof_data <- fit$GOF
			obs_vals <- gof_data[1, ]
			pred_vals <- gof_data[-1, , drop = FALSE]
			
			gof_plot_data <- data.frame()
			for (j in 1:ncol(gof_data)) {
				stat_name <- colnames(gof_data)[j]
				gof_plot_data <- rbind(gof_plot_data, data.frame(
					value = pred_vals[, j],
					statistic = stat_name,
					observed = obs_vals[j],
					stringsAsFactors = FALSE
				))
			}
			
			gof_plot_data$statistic <- relabel(gof_plot_data$statistic, gof_stat_labels)

			p_gof <- ggplot(gof_plot_data, aes(x = value)) +
				geom_histogram(aes(y = after_stat(density)), bins = 30) +
				geom_vline(aes(xintercept = observed),
									color = "red", linewidth = 1) +
				facet_wrap(~ statistic, scales = "free", ncol = 2) +
				labs(title = "Goodness-of-Fit: Observed (Red) vs Posterior Predictive",
						 x = "Value", y = "Density") +
				lame_theme

			plot_list[["gof"]] <- p_gof
		} else if ("gof" %in% plot_types) {
			cli::cli_alert_info("No goodness-of-fit data available - consider setting {.arg gof=TRUE} in model fitting")
		}
	}
	####

	####
	# additive and multiplicative effects
	if ("effects" %in% plot_types) {
		effects_plots <- list()
		
		if (!is.null(fit$APM) && !is.null(fit$BPM)) {
			if (!is.null(fit$a_dynamic) && !is.null(fit$b_dynamic)) {
				# time-varying effects from dynamic parameters
				A <- fit$a_dynamic
				B <- fit$b_dynamic
				
				# reshape to long format
				df_a <- as.data.frame(as.table(A))
				names(df_a) <- c("actor", "time", "effect")
				df_a$type <- "Sender"
				df_a$time <- as.integer(df_a$time)
				
				df_b <- as.data.frame(as.table(B))
				names(df_b) <- c("actor", "time", "effect")
				df_b$type <- "Receiver"
				df_b$time <- as.integer(df_b$time)
				
				effects_time_data <- rbind(df_a, df_b)
				names(effects_time_data)[1] <- "name"  # rename actor to name for consistency
			} else if (!is.null(fit$APM_T)) {
				n_time <- length(fit$APM_T)
				effects_time_data <- data.frame()
				
				for (t in 1:n_time) {
					if (!is.null(fit$APM_T[[t]])) {
						for (i in 1:length(fit$APM_T[[t]])) {
							effects_time_data <- rbind(effects_time_data, data.frame(
								time = t,
								effect = fit$APM_T[[t]][i],
								name = names(fit$APM_T[[t]])[i],
								type = "Sender",
								stringsAsFactors = FALSE
							))
						}
					}
					if (!is.null(fit$BPM_T[[t]])) {
						for (i in 1:length(fit$BPM_T[[t]])) {
							effects_time_data <- rbind(effects_time_data, data.frame(
								time = t,
								effect = fit$BPM_T[[t]][i],
								name = names(fit$BPM_T[[t]])[i],
								type = "Receiver",
								stringsAsFactors = FALSE
							))
						}
					}
				}
				
				if (nrow(effects_time_data) > 0) {
					actor_var <- aggregate(effect ~ name + type, effects_time_data, var)
					top_actors <- head(actor_var[order(-actor_var$effect), ], 20)
					effects_time_data <- effects_time_data[
						effects_time_data$name %in% top_actors$name, 
					]
					
					p_effects_time <- ggplot(effects_time_data,
																	 aes(x = time, y = effect,
																			 color = name, linetype = type)) +
						geom_line(alpha = 0.7) +
						geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
						labs(title = "Top 20 Actors: Effects Over Time",
								 x = "Time Period", y = "Effect",
								 color = "Actor", linetype = "Type") +
						lame_theme
					
					effects_plots[["time_varying"]] <- p_effects_time
				}
			} else {
				sender_data <- data.frame(
					effect = fit$APM,
					name = names(fit$APM),
					type = "Sender",
					stringsAsFactors = FALSE
				)
				
				receiver_data <- data.frame(
					effect = fit$BPM,
					name = names(fit$BPM),
					type = "Receiver",
					stringsAsFactors = FALSE
				)
				
				effects_data <- rbind(sender_data, receiver_data)
				effects_data <- effects_data[order(effects_data$type, effects_data$effect), ]
				effects_data$index <- 1:nrow(effects_data)
				
				p_additive <- ggplot(effects_data, aes(x = index, y = effect, color = type)) +
					geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
					geom_point(size = 1.5, alpha = 0.7) +
					geom_segment(aes(xend = index, yend = 0), alpha = 0.5) +
					labs(title = "Additive Effects (Time-Averaged)",
							 x = "Actor (Sorted)", y = "Effect", color = "Type") +
					lame_theme +
					theme(axis.text.x = element_blank())
				
				effects_plots[["additive"]] <- p_additive
			}
		} else if ("effects" %in% plot_types) {
			cli::cli_alert_info("No additive effects available to plot")
		}
		
		# latent multiplicative effects
		if (!is.null(fit$U) && !is.null(fit$V)) {
			if (length(dim(fit$U)) == 3) {
				U_2d <- apply(fit$U, c(1,2), mean)
				V_2d <- apply(fit$V, c(1,2), mean)
			} else {
				U_2d <- fit$U
				V_2d <- fit$V
			}
			
			if (is.matrix(U_2d) && is.matrix(V_2d) && ncol(U_2d) > 0 && ncol(V_2d) > 0) {
				# separate data frames for u and v (nrow may differ for bipartite)
				u_names <- rownames(U_2d)
				if (is.null(u_names)) u_names <- paste0("U", seq_len(nrow(U_2d)))
				v_names <- rownames(V_2d)
				if (is.null(v_names)) v_names <- paste0("V", seq_len(nrow(V_2d)))
				# the 2-d scatter needs two columns on BOTH sides; bipartite
				# ranks can differ (r_row != r_col), so a rank-1 side falls
				# through to the 1-d layout below
				if (ncol(U_2d) >= 2 && ncol(V_2d) >= 2) {
					u_data <- data.frame(
						x = U_2d[, 1], y = U_2d[, 2],
						name = u_names,
						type = "U (Sender)", stringsAsFactors = FALSE
					)
					v_data <- data.frame(
						x = V_2d[, 1], y = V_2d[, 2],
						name = v_names,
						type = "V (Receiver)", stringsAsFactors = FALSE
					)
				} else {
					u_data <- data.frame(
						x = U_2d[, 1], y = rep(0, nrow(U_2d)),
						name = u_names,
						type = "U (Sender)", stringsAsFactors = FALSE
					)
					v_data <- data.frame(
						x = V_2d[, 1], y = rep(0, nrow(V_2d)),
						name = v_names,
						type = "V (Receiver)", stringsAsFactors = FALSE
					)
				}
				mult_data <- rbind(u_data, v_data)
			} else {
				mult_data <- NULL
				if ("effects" %in% plot_types && length(effects_plots) == 0) {
					cli::cli_alert_info("No multiplicative effects to plot (R=0 or insufficient dimensions)")
				}
			}

			if (!is.null(mult_data)) {
				p_mult <- ggplot(mult_data, aes(x = x, y = y, color = type)) +
					geom_point(size = 2, alpha = 0.7) +
					geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
					geom_vline(xintercept = 0, linetype = "dashed", color = "gray50") +
					labs(title = "Multiplicative Effects",
							 x = "Dimension 1", y = "Dimension 2", color = "Type") +
					lame_theme +
					coord_fixed()

				effects_plots[["multiplicative"]] <- p_mult
			}
		}
		
		if (length(effects_plots) > 0) {
			if (has_patchwork) {
				plot_list[["effects"]] <- patchwork::wrap_plots(effects_plots, ncol = 1)
			} else {
				plot_list[["effects"]] <- effects_plots[[1]]
			}
		}
	}
	####

	####
	# network snapshots at selected time points
	if ("network" %in% plot_types && !is.null(fit$Y_T)) {
		n_time <- length(fit$Y_T)
		
		if (is.null(time.points)) {
			time.points <- c(1, ceiling(n_time/2), n_time)
			time.points <- unique(time.points[time.points <= n_time])
		}
		time.points <- time.points[time.points >= 1 & time.points <= n_time]
		
		network_plots <- list()
		
		for (t in time.points) {
			Y_t <- fit$Y_T[[t]]
			if (!is.null(Y_t)) {
				net_data <- data.frame()
				n <- nrow(Y_t)
				for (i in 1:n) {
					for (j in 1:n) {
						if (i != j && !is.na(Y_t[i,j]) && Y_t[i,j] > 0) {
							net_data <- rbind(net_data, data.frame(
								from = i,
								to = j,
								weight = Y_t[i,j],
								stringsAsFactors = FALSE
							))
						}
					}
				}
				
				if (nrow(net_data) > 0) {
					angles <- seq(0, 2*pi, length.out = n+1)[1:n]
					node_positions <- data.frame(
						node = 1:n,
						x = cos(angles),
						y = sin(angles)
					)
					
					net_data <- merge(net_data, node_positions, by.x = "from", by.y = "node")
					names(net_data)[names(net_data) %in% c("x", "y")] <- c("x_from", "y_from")
					net_data <- merge(net_data, node_positions, by.x = "to", by.y = "node")
					names(net_data)[names(net_data) %in% c("x", "y")] <- c("x_to", "y_to")
					
					p_net <- ggplot() +
						geom_segment(data = net_data,
												aes(x = x_from, y = y_from, xend = x_to, yend = y_to),
												alpha = 0.3, color = "gray50") +
						geom_point(data = node_positions,
											aes(x = x, y = y), size = 3) +
						labs(title = paste("Network at Time", t)) +
						theme_bw() +
						theme(
							panel.border    = element_blank(),
							axis.ticks      = element_blank(),
							axis.text       = element_blank(),
							axis.title      = element_blank(),
							legend.position = "top"
						) +
						coord_fixed()
					
					network_plots[[paste0("t", t)]] <- p_net
				}
			}
		}
		
		if (length(network_plots) > 0) {
			if (has_patchwork) {
				plot_list[["network"]] <- patchwork::wrap_plots(network_plots, ncol = length(network_plots))
			} else {
				plot_list[["network"]] <- network_plots[[1]]
			}
		}
	}
	####

	####
	# report which plots are generated
	if (length(plot_list) > 0) {
		plot_names <- names(plot_list)
		cli::cli_alert_info("Generating LAME diagnostic plots: {.field {paste(plot_names, collapse=', ')}}")
	} else {
		cli::cli_alert_warning("No plots generated - insufficient data or no parameters to display")
		return(invisible(NULL))
	}
	
	# render plots
	if (pages == "single" && has_patchwork) {
		# single page layout
		if (length(plot_list) > 0) {
			cli::cli_alert_info("Combining plots into single page layout")
			combined_plot <- patchwork::wrap_plots(plot_list, ncol = 1) +
				patchwork::plot_annotation(
					title = "LAME Model Diagnostics",
					theme = theme(plot.title = element_text(size = 14, face = "bold"))
				)
			print(combined_plot)
		}
	} else {
		# multi-page layout
		if (ask && length(plot_list) > 1) {
			cli::cli_alert_info("Interactive mode: Press {.kbd Enter} to view each plot")
			oask <- devAskNewPage(TRUE)
			on.exit(devAskNewPage(oask))
		}
		
		for (i in seq_along(plot_list)) {
			p <- plot_list[[i]]
			plot_name <- names(plot_list)[i]
			if (!ask) {
				cli::cli_alert_info("Displaying {.field {plot_name}} plot")
			}
			print(p)
			if (ask && length(plot_list) > 1) {
				readline(prompt = "Press [enter] to continue")
			}
		}
	}
	####

	invisible(NULL)
}
