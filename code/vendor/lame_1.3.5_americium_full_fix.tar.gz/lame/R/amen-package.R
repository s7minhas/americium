#' Longitudinal Additive and Multiplicative Effects Models for Networks
#' 
#' An extension of the 'amen' package specifically designed for longitudinal
#' network analysis. This package provides tools for fitting Additive and
#' Multiplicative Effects (AME) models to longitudinal/replicated relational
#' data with several extensions: (1) handling of changing actor
#' compositions across time periods, allowing for networks with different sets
#' of actors at each time point; (2) significant performance improvements through
#' C++ implementations via Rcpp and RcppArmadillo; (3) specialized functions for
#' temporal network dynamics. The package supports six data types:
#' normal (nrm), binary (bin), ordinal (ord), Poisson count (poisson),
#' censored binary (cbin),
#' and fixed-rank nomination (frn). Based on the AME framework originally developed
#' by Hoff (2009) and Hoff, Fosdick, Volfovsky and Stovel (2013).
#'
#' \strong{Estimators.} The package offers two estimation routes:
#' \itemize{
#'   \item \code{\link{ame}} / \code{\link{lame}} -- the Bayesian MCMC
#'     estimators, for calibrated posterior inference (cross-sectional and
#'     longitudinal respectively).
#'   \item \code{\link{ame_als}} / \code{\link{lame_als}} -- a fast,
#'     MCMC-free point estimator by iterative block coordinate descent, with
#'     bootstrap uncertainty via \code{\link{ame_als_bootstrap}}. Use it
#'     for rapid model exploration, rank selection and starting values; use the
#'     MCMC estimators for final inference.
#' }
#'
#' \tabular{ll}{ Package: \tab lame\cr Type: \tab Package\cr License: \tab
#' MIT \cr }
#'
#' @name lame-package
#' @aliases lame-package
#' @author Shahryar Minhas, Tosin Salau, Cassy Dorff
#' 
#' Maintainer: Shahryar Minhas <minhassh@@msu.edu>
#' @keywords internal
#' @import Rcpp
#' @import ggplot2
#' @import ggrepel
#' @importFrom Rcpp evalCpp
#' @importFrom graphics abline arrows hist matplot par points text
#' @importFrom stats cor cov density median pnorm qnorm quantile rgamma rnorm runif sd symnum time var pgamma qgamma
#' @importFrom utils setTxtProgressBar txtProgressBar
#' @useDynLib lame, .registration = TRUE
#'
#' @examples
#' \donttest{
#' data(YX_nrm)
#' fit <- ame(YX_nrm$Y, Xdyad = YX_nrm$X, burn = 10, nscan = 100, odens = 1,
#'            family = "normal", verbose = FALSE)
#' summary(fit)
#' }
#'
#'
#'
NULL

# package-local mutable state (show-once message flags and similar);
# kept in an environment so we never write to the user's options()
.lame_state <- new.env(parent = emptyenv())




#' binary relational data and covariates
#' 
#' a synthetic dataset that includes binary relational data as well as
#' information on eight covariates
#' 
#' 
#' @name YX_bin
#' @docType data
#' @usage data(YX_bin)
#' @format The format is: List of 2 $ Y: num \[1:100, 1:100\] NA 0 0 0 0 0 0 0 0
#' 1 ...  $ X: num \[1:100, 1:100, 1:8\] 1 1 1 1 1 1 1 1 1 1 ...  ..- attr(*,
#' "dimnames")=List of 3 .. ..$ : NULL .. ..$ : NULL .. ..$ : chr \[1:8\]
#' "intercept" "rgpa" "rsmoke" "cgpa" ...
#' @keywords datasets
#' @examples
#' 
#' data(YX_bin)
#' gof_stats(YX_bin$Y) 
#' 
NULL





#' Censored binary nomination data and covariates
#' 
#' a synthetic dataset that includes relational data where the number of
#' nominations per row is censored at 10, along with information on eight
#' covariates
#' 
#' 
#' @name YX_cbin
#' @docType data
#' @usage data(YX_cbin)
#' @format The format is: List of 2 $ Y: num \[1:100, 1:100\] NA 0 0 0 1 0 0 0 0
#' 3 ...  $ X: num \[1:100, 1:100, 1:8\] 1 1 1 1 1 1 1 1 1 1 ...  ..- attr(*,
#' "dimnames")=List of 3 .. ..$ : NULL .. ..$ : NULL .. ..$ : chr \[1:8\]
#' "intercept" "rgpa" "rsmoke" "cgpa" ...
#' @keywords datasets
#' @examples
#' 
#' data(YX_cbin)
#' gof_stats(YX_cbin$Y) 
#' 
NULL





#' Fixed rank nomination data and covariates
#' 
#' a synthetic dataset that includes fixed rank nomination data as well as
#' information on eight covariates
#' 
#' 
#' @name YX_frn
#' @docType data
#' @usage data(YX_frn)
#' @format The format is: List of 2 $ Y: num \[1:100, 1:100\] NA 0 0 0 1 0 0 0 0
#' 3 ...  $ X: num \[1:100, 1:100, 1:8\] 1 1 1 1 1 1 1 1 1 1 ...  ..- attr(*,
#' "dimnames")=List of 3 .. ..$ : NULL .. ..$ : NULL .. ..$ : chr \[1:8\]
#' "intercept" "rgpa" "rsmoke" "cgpa" ...
#' @keywords datasets
#' @examples
#' 
#' data(YX_frn)
#' gof_stats(YX_frn$Y) 
#' 
NULL





#' normal relational data and covariates
#' 
#' a synthetic dataset that includes continuous (normal) relational data as
#' well as information on eight covariates
#' 
#' 
#' @name YX_nrm
#' @docType data
#' @usage data(YX_nrm)
#' @format The format is: List of 2 $ Y: num \[1:100, 1:100\] NA -4.05 -0.181
#' -3.053 -1.579 ...  $ X: num \[1:100, 1:100, 1:8\] 1 1 1 1 1 1 1 1 1 1 ...  ..-
#' attr(*, "dimnames")=List of 3 .. ..$ : NULL .. ..$ : NULL .. ..$ : chr \[1:8\]
#' "intercept" "rgpa" "rsmoke" "cgpa" ...
#' @keywords datasets
#' @examples
#' 
#' data(YX_nrm)
#' gof_stats(YX_nrm$Y)
#' 
#' 
NULL





#' ordinal relational data and covariates
#' 
#' a synthetic dataset that includes ordinal relational data as well as
#' information on seven covariates
#' 
#' 
#' @name YX_ord
#' @docType data
#' @usage data(YX_ord)
#' @format The format is: List of 2 $ Y: num \[1:100, 1:100\] NA 0 3 0 3 1 0 1 1
#' 0 ...  $ X: num \[1:100, 1:100, 1:7\] 1 1 1 1 1 1 1 1 1 1 ...  ..- attr(*,
#' "dimnames")=List of 3 .. ..$ : NULL .. ..$ : NULL .. ..$ : chr \[1:7\] "rgpa"
#' "rsmoke" "cgpa" "csmoke" ...
#' @keywords datasets
#' @examples
#' 
#' data(YX_ord)
#' gof_stats(YX_ord$Y)
#' 
NULL


#' synthetic longitudinal binary relational data (latent-scale)
#'
#' a synthetic 50-actor, 4-period dataset used by the vignettes. The
#' shipped \code{Y} array holds the \emph{latent probit-scale predictor}
#' (range roughly -24 to 20), not 0/1 ties. To recover the binary tie
#' indicator the dataset name implies, threshold at zero:
#' \code{Y_bin <- (YX_bin_long$Y > 0) * 1}. If passed unthresholded to
#' \code{lame(..., family = "binary")} the fit will warn and silently
#' apply the same \code{Y > 0} threshold.
#'
#' @name YX_bin_long
#' @docType data
#' @usage data(YX_bin_long)
#' @format A list with two elements:
#'   \describe{
#'     \item{Y}{Numeric array \code{[50, 50, 4]}. Latent probit-scale
#'       predictor; threshold at 0 to get the binary tie indicator.}
#'     \item{X}{Numeric array \code{[50, 50, 3, 4]} of dyadic covariates.}
#'   }
#' @keywords datasets
#' @examples
#'
#' data(YX_bin_long)
#' # threshold latent z to 0/1 before computing binary GOF stats
#' Yt <- 1 * (YX_bin_long$Y[, , 1] > 0)
#' diag(Yt) <- NA
#' gof_stats(Yt)
#'
NULL


#' @title Sampson's monastery data
#'
#' @description 
#' Several dyadic variables measured on 18 members of a monastery. 
#'
#' @format 
#' A socioarray whose dimensions represent nominators, nominatees and relations. 
#' Each monk was asked to rank up to three other monks on a variety of positive 
#' and negative relations. A rank of three indicates the "highest" ranking for 
#' a particular relational variable. The relations \code{like_m1} and \code{like_m2}
#' are evaluations of liking at one and two timepoints previous to when the
#' other relations (including \code{like}) were measured. In the copy of this
#' array that circulated with \pkg{amen}, the three liking layers had their
#' monks in a different order from the array's row and column names; they
#' are re-aligned here so every layer follows the same actor labels.
#' 
#' @source
#' Originally available at \code{http://moreno.ss.uci.edu/data.html#sampson}
#' (site no longer accessible).
#'
#' @name sampsonmonks
NULL


#' @title Cold War data
#'
#' @description 
#' Positive and negative relations between countries during the cold war
#'
#' @format 
#' A list including the following dyadic and nodal variables:
#' \itemize{
#' \item \code{cc}: a socioarray of ordinal levels of military 
#' cooperation (positive) and conflict (negative), every 5 years; 
#' \item \code{distance}: between-country distance (in thousands of kilometers); 
#' \item \code{gdp}: country gdp in dollars every 5 years; 
#' \item \code{polity}: country polity every 5 years.  
#' }
#' @source
#' Xun Cao : \url{https://polisci.la.psu.edu/people/xuc11/}
#' 
#' @name coldwar
NULL


#' @title Comtrade data
#'
#' @description
#' Eleven years of import and export data between 229 countries. 
#' The data use the SITC Rev. 1 commodity classification, aggregated at the 
#' first level (AG1). 
#'  
#' @format A list consisting of a socioarray \code{Trade} and a vector 
#' \code{dollars2010} of inflation rates. The socioarray gives 
#' yearly trade volume (exports and imports) 
#' in dollars for 10 different commodity classes 
#' for eleven years between 229 countries. This gives a five-way 
#' array. The first index is the reporting country, so 
#' \code{Trade[i,j,t,k,1]} is what \code{i} reports for exports to 
#' \code{j}, but in general this is not the same as 
#' \code{Trade[j,i,t,k,2]}, what \code{j} reports as importing from \code{i}. 
#' 
#' @source \url{https://comtrade.un.org/}, \url{https://www.measuringworth.com/}
#' 
#' @name comtrade
NULL


#' @title Lazega's law firm data
#'
#' @description 
#' Several nodal and dyadic variables measured on 71 attorneys in a law firm. 
#'
#' @format 
#' A list consisting of a socioarray \code{Y} and a nodal attribute matrix \code{X}. 
#' 
#' The dyadic variables in \code{Y} include three binary networks: advice, friendship
#' and co-worker status. 
#' 
#' The categorical nodal attributes in \code{X} are coded as follows: 
#' \itemize{
#' \item status (1=partner, 2=associate)
#' \item office (1=Boston, 2=Hartford, 3=Providence) 
#' \item practice (1=litigation, 2=corporate) 
#' \item law school (1=Harvard or Yale, 2=UConn, 3=other)  
#'  }
#' \code{seniority} and \code{age} are given in years, and \code{female} is 
#' a binary indicator. 
#' 
#' @source
#' Originally available at \code{http://moreno.ss.uci.edu/data.html#lazega}
#' (site no longer accessible).
#'
#' @name lazegalaw
NULL


#' AddHealth community 3 data
#'
#' A valued sociomatrix (Y) and matrix of nodal attributes (X) for 
#' students in community 3 of the AddHealth study. 
#' \itemize{
#' \item Y: A sociomatrix in which the value of the edge corresponds to an ad-hoc measure of intensity of the relation. Note that students were only allowed to nominate up to 5 male friends and 5 female friends. 
#' \item X: Matrix of students attributes, including sex, race (1=white, 2=black, 3=hispanic, 4=asian, 5=mixed/other) and grade. 
#' } 
#' Originally available at \code{http://moreno.ss.uci.edu/data.html#adhealth}
#' (site no longer accessible).
#' @docType data
#' @keywords datasets
#' @format list
#' @name addhealthc3
#' @usage data(addhealthc3)
NULL

#' AddHealth community 9 data
#'
#' A valued sociomatrix (Y) and matrix of nodal attributes (X) for 
#' students in community 9 of the AddHealth study. 
#' \itemize{
#' \item Y: A sociomatrix in which the value of the edge corresponds to an ad-hoc measure of intensity of the relation. Note that students were only allowed to nominate up to 5 male friends and 5 female friends. 
#' \item X: Matrix of students attributes, including sex, race (1=white, 2=black, 3=hispanic, 4=asian, 5=mixed/other) and grade. 
#' } 
#' Originally available at \code{http://moreno.ss.uci.edu/data.html#adhealth}
#' (site no longer accessible).
#' @docType data
#' @keywords datasets
#' @format list
#' @name addhealthc9
#' @usage data(addhealthc9)
NULL



#' @title International relations in the 90s
#'
#' @description 
#' A relational dataset recording 
#' a variety of nodal and dyadic variables on countries in the 1990s,
#' including information on conflicts, trade and other variables. 
#' Except for the conflict variable, the variables are averages
#' across the decade. 
#'
#' @format 
#' A list consisting of a socioarray \code{dyadvars} of 
#' dyadic variables and matrix  \code{nodevars} of nodal variables. 
#' The dyadic variables include
#' \itemize{
#' \item total number of conflicts;
#' \item exports (in billions of dollars);
#' \item distance (in thousands of kilometers);
#' \item number of shared IGOs (averages across the years);
#' \item polity interaction. 
#' } 
#' The nodal variables include
#' \itemize{
#' \item population (in millions); 
#' \item gdp (in billions of dollars); 
#' \item polity 
#' }
#' 
#' @source Michael Ward.
#' 
#' @name IR90s
NULL



#' @title Dutch college data
#'
#' @description
#' Longitudinal relational measurements and nodal characteristics 
#' of Dutch college students, described in 
#' van de Bunt, van Duijn, and Snijders (1999). 
#' The time interval between the first four measurements was 
#' three weeks, whereas the interval between the last three 
#' was six weeks. 
#' 
#' @format A list consisting of a socioarray \code{Y} and a matrix 
#' \code{X}  of static nodal attributes. The relational 
#' measurements range from -1 to 4, indicating the following:
#' \itemize{
#' \item -1 a troubled or negative relationship
#' \item  0 don't know
#' \item  1 neutral relationship
#' \item  2 friendly
#' \item  3 friendship
#' \item  4 best friends
#' }
#' 
#' @source
#' Originally available at \code{http://moreno.ss.uci.edu/data.html#vdb}
#' (site no longer accessible).
#'
#' @name dutchcollege
NULL




#' @title Sheep dominance data
#'
#' @description 
#' Number of dominance encounters between 28 female bighorn sheep. 
#' Cell (i,j) records the number of times sheep i dominated sheep j. 
#' From Hass (1991). 
#'  
#' @format 
#' A list consisting of the following:
#' \itemize{
#' \item \code{dom}: a directed socioarray recording the number of 
#' dominance encounters. 
#' \item \code{age}: the age of each sheep in years. 
#' }
#' 
#' @source
#' Originally available at \code{http://moreno.ss.uci.edu/data.html#sheep}
#' (site no longer accessible).
#' @name sheep
NULL
