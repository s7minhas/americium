####
# align latent positions across time to prevent arbitrary sign/rotation flips
# unipartite: u is [n, r, t]
align_over_time_unip <- function(U) {
	if (is.null(U) || length(dim(U)) != 3L) return(U)
	Tn <- dim(U)[3]
	if (Tn < 2L) return(U)
	U_al <- U
	for (t in 2:Tn) {
		M <- crossprod(U_al[,,t], U_al[,,t-1])
		if (!all(is.finite(M))) {
			next
		}
		sv <- tryCatch(base::svd(M), error = function(e) NULL)
		if (!is.null(sv)) {
			Ropt <- sv$u %*% t(sv$v)
			U_al[,,t] <- U_al[,,t] %*% Ropt
		}
	}
	U_al
}
####

####
# bipartite: u [na, ra, t], v [nb, rb, t], g [ra, rb]
align_over_time_bip <- function(U, V, G) {
	if (is.null(U) || is.null(V) || length(dim(U)) != 3L || length(dim(V)) != 3L) {
		return(list(U = U, V = V, G = G))
	}
	Tn <- dim(U)[3]
	if (Tn < 2L) return(list(U = U, V = V, G = G))
	U_al <- U; V_al <- V; G_al <- G
	for (t in 2:Tn) {
		MU <- crossprod(U_al[,,t], U_al[,,t-1])
		MV <- crossprod(V_al[,,t], V_al[,,t-1])
		if (!all(is.finite(MU)) || !all(is.finite(MV))) {
			next
		}
		su <- tryCatch(svd(MU), error = function(e) NULL)
		sv <- tryCatch(svd(MV), error = function(e) NULL)
		if (is.null(su) || is.null(sv)) {
			next
		}
		RU <- su$u %*% t(su$v)
		RV <- sv$u %*% t(sv$v)
		U_al[,,t] <- U_al[,,t] %*% RU
		V_al[,,t] <- V_al[,,t] %*% RV
		# keep u g v' invariant over rotations
		G_al <- t(RU) %*% G_al %*% RV
	}
	list(U = U_al, V = V_al, G = G_al)
}
####

####
# estimate ar(1)-like persistence from aligned latent series
estimate_rho_from_U <- function(U) {
	if (is.null(U) || length(dim(U)) != 3L) return(NA_real_)
	Tn <- dim(U)[3]
	if (Tn < 2L) return(NA_real_)
	num <- 0; den <- 0
	for (t in 2:Tn) {
		Ut  <- U[,,t]
		Ut1 <- U[,,t-1]
		num <- num + sum(Ut * Ut1, na.rm = TRUE)
		den <- den + sum(Ut1 * Ut1, na.rm = TRUE)
	}
	if (den > 0) num / den else NA_real_
}
####
