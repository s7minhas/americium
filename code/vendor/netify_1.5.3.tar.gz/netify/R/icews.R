#' Event data slice from ICEWS
#'
#' event data from icews for select countries from 2002 to 2014,
#' and additional nodal variables from the world bank and polity iv.
#'
#' @format a data frame with dyadic observations and the following variables:
#'   \describe{
#'     \item{i}{source country}
#'     \item{j}{target country}
#'     \item{year}{year of observation}
#'     \item{id}{observation identifier}
#'     \item{verbCoop}{verbal cooperation score}
#'     \item{matlCoop}{material cooperation score}
#'     \item{verbConf}{verbal conflict score}
#'     \item{matlConf}{material conflict score}
#'     \item{i_year}{year for source country}
#'     \item{j_year}{year for target country}
#'     \item{i_polity2}{polity iv democracy score for source country}
#'     \item{j_polity2}{polity iv democracy score for target country}
#'     \item{i_iso3c}{iso 3166-1 alpha-3 code for source country}
#'     \item{j_iso3c}{iso 3166-1 alpha-3 code for target country}
#'     \item{i_region}{region for source country}
#'     \item{j_region}{region for target country}
#'     \item{i_gdp}{gdp for source country}
#'     \item{j_gdp}{gdp for target country}
#'     \item{i_log_gdp}{log gdp for source country}
#'     \item{j_log_gdp}{log gdp for target country}
#'     \item{i_pop}{population for source country}
#'     \item{j_pop}{population for target country}
#'     \item{i_log_pop}{log population for source country}
#'     \item{j_log_pop}{log population for target country}
#'   }
#'
#' @name icews
#' @docType data
#' @usage data(icews)
#' @keywords datasets
#'
#' @references boschee, e., lautenschlager, j., o'brien, s., shellman, s.,
#' starz, j., and ward, m. (2015). icews coded event data. harvard dataverse.
#' \doi{10.7910/dvn/28075}.
#'
#' @source icews coded event data, harvard dataverse.
#'
#' @examples
#' data(icews)
#' icews[1:3, ]
#'
#' @author cassy dorff, shahryar minhas
#'
NULL
