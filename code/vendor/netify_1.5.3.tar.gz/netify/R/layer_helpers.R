#' Helper function for layer_netify to set layer labels
#'
#' @param netlet_list list of netlet objects
#' @param layer_labels character vector of layer labels
#' @return character vector of layer labels
#' @author cassy dorff, shahryar minhas
#'
#' @keywords internal
#' @noRd

set_layer_labels <- function(netlet_list, layer_labels) {
	# if provided make sure the number of labels
	# are the same as the length of the netlet list obj
	if (!is.null(layer_labels)) {
		if (length(layer_labels) != length(netlet_list)) {
			cli::cli_abort(
				"The number of layer labels must be
				the same as the number of netlets in `netlet_list`."
			)
		}
	}

	# if layer labels not present see if we can pull them from
	# the list object
	if (is.null(layer_labels)) {
		existing_names <- names(netlet_list)
		if (is.null(existing_names)) {
			# no names at all, generate generic labels
			layer_labels <- paste0("layer", seq_along(netlet_list))
		} else {
			# some names exist, fill in missing ones
			layer_labels <- existing_names
			missing_names <- which(is.na(existing_names) | existing_names == "")
			if (length(missing_names) > 0) {
				layer_labels[missing_names] <- paste0("layer", missing_names)
			}
		}
	}

	#
	return(layer_labels)
}

#' cycle through elements of a netlet object and make sure
#' that they are identical before we try to merge into
#' a multilayer netify object
#'
#' @param a_list list object to check
#' @param elems character vector with names of elements to check
#' @param msg character vector of length two warning user
#' if elements are found to be not identical. first part of
#' vector is the preamble before the element name and
#' second part is what should come after the element name.
#' @return NULL
#' @author cassy dorff, shahryar minhas
#'
#' @keywords internal
#' @noRd

check_layer_compatible <- function(a_list, elems, msg) {
	# cycle through elements so we can name the offender on failure
	for (elem in elems) {
		# check if that attribute is identical across layers
		elem_check <- identical_recursive(
			lapply(a_list, `[[`, elem)
		)

		# if not identical then throw error and stop
		if (!elem_check) {
			cli::cli_abort(
				paste0(msg[1], elem, msg[2])
			)
		}
	}
}

#' helper function for layer_netify to extract attributes
#' from listed netlet objects
#'
#' @param a_list named list object
#' @param attrib character string of attribute to extract
#' @param list_format logical, if TRUE return list of attributes
#' @param get_unique logical, if TRUE return unique values of attribute
#' @return attribute values
#' @author cassy dorff, shahryar minhas
#'
#' @keywords internal
#' @noRd

get_attribs <- function(
	a_list, attrib,
	list_format = FALSE, get_unique = FALSE) {
	out <- lapply(a_list, `[[`, attrib)
	if (list_format) {
		return(out)
	}
	if (!list_format) {
		out <- unlist(out, use.names = FALSE)
		if (get_unique) {
			return(unique(out))
		} else {
			return(out)
		}
	}
}

#' reduce and combine multiple nodal attributes of netify objects
#' into a single nodal attribute. mainly for use within the
#' layer_netify function
#'
#' @param attribs_list list of attributes from each netlet
#' @param msrmnts_list list of msrmnts from each netlet
#' @param netlet_type character string of netlet type
#' @param layer_labels character vector of layer labels
#' @return nodal attribute data.frame
#' @author cassy dorff, shahryar minhas
#'
#' @keywords internal
#' @noRd

reduce_combine_nodal_attr <- function(
	attribs_list, msrmnts_list, netlet_type) {
	# extract nodal data from each netlet into list
	nodal_data_list <- lapply(attribs_list, `[[`, "nodal_data")

	# drop any null elements
	nodal_data_list <- nodal_data_list[!vapply(nodal_data_list, is.null, logical(1))]

	# if only one element left then just
	# return that one nodal data element
	if (length(nodal_data_list) == 1) {
		return(nodal_data_list[[1]])
	}

	# if more than one element left then try and combine
	if (length(nodal_data_list) > 1) {
		# get a list of the vars across the netlets
		nvars <- get_attribs(msrmnts_list, "nvars", get_unique = TRUE)

		# check that id columns are identical across netlets
		n_id_check <- if (netlet_type == "cross_sec") {
			identical_recursive(lapply(nodal_data_list, function(x) x[, 1]))
		} else {
			identical_recursive(lapply(nodal_data_list, function(x) x[, 1:2]))
		}

		if (!n_id_check) {
			cli::cli_warn(c(
				"!" = "Nodal data id columns are not identical across netlets; nodal data will not be merged.",
				"i" = "Re-add nodal attributes manually with {.fn add_node_vars}."
			))
			return(NULL)
		}

		# cbind nodal data when id columns match
		if (n_id_check) {
			# pre-filter nvars for each slice
			ndata_list <- lapply(nodal_data_list, function(slice) {
				nvars_slice <- names(slice)[names(slice) %in% nvars]
				slice[, nvars_slice, drop = FALSE]
			})

			ndata <- do.call("cbind", ndata_list)

			if (netlet_type == "cross_sec") {
				ndata <- cbind(actor = nodal_data_list[[1]][, 1], ndata)
			} else {
				ndata <- cbind(nodal_data_list[[1]][, 1:2], ndata)
			}
			return(ndata)
		}
	}
}

#' reduce and combine multiple dyadic attributes of netify objects
#' into a single dyadic attribute. mainly for use within the
#' layer_netify function
#'
#' @param attribs_list list of attributes from each netlet
#' @param msrmnts_list list of msrmnts from each netlet
#' @param netlet_type character string of netlet type
#' @return dyad attribute data.frame
#' @author cassy dorff, shahryar minhas
#'
#' @keywords internal
#' @noRd

reduce_combine_dyad_attr <- function(
	attribs_list, msrmnts_list, netlet_type, layer_labels = NULL) {
	# extract dyad data from each netlet into list
	dyad_data_list <- lapply(attribs_list, `[[`, "dyad_data")

	# drop any null elements
	null_check <- vapply(dyad_data_list, function(x) {
		is.null(x) || is.null(x[[1]])
	}, logical(1))
	dyad_data_list <- dyad_data_list[!null_check]
	layer_labels <- layer_labels[!null_check]
	if (is.null(layer_labels) || length(layer_labels) != length(dyad_data_list)) {
		layer_labels <- paste0("layer", seq_along(dyad_data_list))
	}

	# if only one element left then just
	# return that one dyad data element
	if (length(dyad_data_list) == 1) {
		return(dyad_data_list[[1]])
	}

	# if more than one element left then try and combine
	if (length(dyad_data_list) > 1) {
		# get a list of the vars across the netlets
		dvars <- get_attribs(msrmnts_list, "dvars", get_unique = TRUE)
		layer_dvars <- lapply(dyad_data_list, function(dd) {
			unique(unlist(lapply(dd, names), use.names = FALSE))
		})
		colliding_dvars <- names(table(unlist(layer_dvars, use.names = FALSE))[
			table(unlist(layer_dvars, use.names = FALSE)) > 1L
		])

		# check that id row/col and time periods are identical across netlets
		t_check <- identical_recursive(lapply(dyad_data_list, names))

		# extract first time period's first variable matrix
		first_elements <- lapply(dyad_data_list, function(x) {
			first_time <- x[[1]]
			if (length(first_time) > 0) {
				list(
					rows = rownames(first_time[[1]]),
					cols = colnames(first_time[[1]])
				)
			} else {
				list(rows = NULL, cols = NULL)
			}
		})

		r_check <- identical_recursive(lapply(first_elements, `[[`, "rows"))
		c_check <- identical_recursive(lapply(first_elements, `[[`, "cols"))

		if (!all(c(t_check, r_check, c_check))) {
			cli::cli_alert_warning(
				"Warning: Dyad data id columns are not identical across netlets,
				dyad data will not be merged from netlets, you can readd dyad
				attributes manually using the `add_dyad` function."
			)
			return(NULL)
		}

		# combine matrices when id columns match
		if (all(c(t_check, r_check, c_check))) {
			# get time periods from first dyad_data element
			t_pds <- names(dyad_data_list[[1]])

			# pre-allocate list
			ddata <- vector("list", length(t_pds))
			names(ddata) <- t_pds

			# process each time period
			for (tt_idx in seq_along(t_pds)) {
				tt <- t_pds[tt_idx]

				# pre-allocate combined_vars with known size
				combined_vars <- list()

				# iterate through each netlet's dyad data for this time period
				for (dd_idx in seq_along(dyad_data_list)) {
					netlet_dyad_data <- dyad_data_list[[dd_idx]]
					time_period_data <- netlet_dyad_data[[tt]]

					if (!is.null(time_period_data) && length(time_period_data) > 0) {
						# direct assignment
						for (var_name in names(time_period_data)) {
							if (var_name %in% dvars) {
								out_name <- if (var_name %in% colliding_dvars) {
									paste(layer_labels[dd_idx], var_name, sep = "_")
								} else {
									var_name
								}
								combined_vars[[out_name]] <- time_period_data[[var_name]]
							}
						}
					}
				}

				# store combined variables for this time period
				ddata[[tt_idx]] <- combined_vars
			}

			#
			return(ddata)
		}
	}
}
